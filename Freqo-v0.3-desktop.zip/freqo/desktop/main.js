const {app,BrowserWindow,session,shell}=require('electron');
const fs=require('fs'),path=require('path');
let url=process.env.FREQO_URL||'http://localhost:3000';
try{url=JSON.parse(fs.readFileSync(path.join(__dirname,'config.json'))).url||url}catch{}
app.whenReady().then(()=>{
 session.defaultSession.setPermissionRequestHandler((wc,perm,cb)=>cb(perm==='media'));
 session.defaultSession.setPermissionCheckHandler((wc,perm)=>perm==='media');
 const w=new BrowserWindow({width:1100,height:760,minWidth:420,backgroundColor:'#060a14',icon:path.join(__dirname,'icon.png'),autoHideMenuBar:true});
 const load=()=>w.loadURL(url);
 w.webContents.on('did-fail-load',(e,c,d,u,main)=>{if(!main)return;
  w.loadURL('data:text/html;charset=utf-8,'+encodeURIComponent('<body style="background:#060a14;color:#e8eeff;font:16px system-ui;display:grid;place-items:center;height:100vh;text-align:center"><div><h2>Freqo est injoignable</h2><p>Vérifie ta connexion. Nouvelle tentative dans quelques secondes…</p></div>'));
  setTimeout(load,5000)});
 w.webContents.setWindowOpenHandler(({url:u})=>{shell.openExternal(u);return{action:'deny'}});
 load()});
app.on('window-all-closed',()=>app.quit());
