// Freqo v0.1 — signalisation WebRTC + comptes, amis, factions, formules (tout vérifié côté serveur)
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const {WebSocketServer}=require('ws');
const PORT=process.env.PORT||3000,REQ=+process.env.VOICE_REQ_SEC||36000,MAXP=8;
const FILE=path.join(process.env.DATA_DIR||__dirname,'data.json'),PUB=path.join(__dirname,'public');
let db={users:{},factions:{},rooms:{}};try{db=JSON.parse(fs.readFileSync(FILE))}catch{}
setInterval(()=>fs.writeFile(FILE,JSON.stringify(db),()=>{}),10000);
const rank={free:0,plus:1,clan:2},rid=()=>crypto.randomBytes(5).toString('hex');
const conns=new Map(),where=new Map(),rooms={};
for(let i=1;i<=50;i++)rooms['f'+i]=new Set();
Object.keys(db.rooms).forEach(k=>rooms[k]=new Set());
const send=(w,m)=>w&&w.readyState===1&&w.send(JSON.stringify(m));
const to=(id,m)=>send(conns.get(id),m);
const pubRoom=r=>/^f\d/.test(r||'')||(db.rooms[r]&&!db.rooms[r].priv);
const radar=()=>({t:'radar',freqs:Array.from({length:50},(_,i)=>rooms['f'+(i+1)].size),custom:Object.values(db.rooms).filter(r=>!r.priv).map(r=>({id:r.id,name:r.name,n:rooms[r.id].size}))});
const bcast=()=>{const m=radar();conns.forEach(w=>send(w,m))};
const meOf=u=>{const f=db.factions[u.faction];return{id:u.id,name:u.name,plan:u.plan,voice:u.voice,req:REQ,theme:u.theme,frame:u.frame,set:u.set,
 friends:u.friends.map(i=>db.users[i]).filter(Boolean).map(x=>({name:x.name,on:conns.has(x.id),room:pubRoom(where.get(x.id))?where.get(x.id):null})),
 faction:f?{...f,members:f.members.map(i=>{const x=db.users[i];return{name:x&&x.name,h:f.owner===u.id&&u.plan==='clan'&&x?+(x.voice/3600).toFixed(1):undefined}})}:null,
 myRooms:Object.values(db.rooms).filter(r=>r.owner===u.id)}};
const push=u=>u&&to(u.id,{t:'me',me:meOf(u)});
const pushFriends=u=>Object.values(db.users).forEach(o=>o.friends.includes(u.id)&&conns.has(o.id)&&push(o));
function leave(id){const r=where.get(id);if(!r)return;rooms[r].delete(id);where.delete(id);rooms[r].forEach(p=>to(p,{t:'left',id}));bcast()}
const server=http.createServer((q,s)=>{
 if(q.url==='/health'){s.writeHead(200);return s.end('ok')}
 if(q.url==='/ice'){s.writeHead(200,{'Content-Type':'application/json'});return s.end(process.env.ICE_SERVERS||'[{"urls":"stun:stun.l.google.com:19302"}]')}
 const p=path.join(PUB,q.url==='/'?'index.html':decodeURIComponent(q.url.split('?')[0]));
 if(!p.startsWith(PUB)||!fs.existsSync(p)||fs.statSync(p).isDirectory()){s.writeHead(404);return s.end()}
 s.writeHead(200,{'Content-Type':({'.html':'text/html;charset=utf-8','.png':'image/png','.js':'text/javascript','.webmanifest':'application/manifest+json'})[path.extname(p)]||'application/octet-stream'});fs.createReadStream(p).pipe(s)});
const wss=new WebSocketServer({server});
wss.on('connection',ws=>{let u;
 ws.on('message',raw=>{let m;try{m=JSON.parse(raw)}catch{return}
  const err=e=>send(ws,{t:'err',e}),all=()=>Object.values(db.users);
  if(m.t==='hello'){
   const name=String(m.name||'').trim().slice(0,20);
   u=all().find(x=>m.token&&x.token===m.token);
   if(!u){if(name.length<2)return err('Pseudo trop court (2 caractères minimum)');
    if(all().some(x=>x.name.toLowerCase()===name.toLowerCase()))return err('Ce pseudo est déjà pris');
    const id=rid();u=db.users[id]={id,name,token:crypto.randomBytes(16).toString('hex'),plan:'free',voice:0,friends:[],faction:null,theme:'blue',frame:'none',set:{notif:true,noFriends:false}}}
   const old=conns.get(u.id);if(old&&old!==ws){leave(u.id);conns.delete(u.id);old.close()}
   conns.set(u.id,ws);send(ws,{t:'hello',token:u.token,me:meOf(u)});send(ws,radar());pushFriends(u);return}
  if(!u)return;
  const R=rank[u.plan];
  switch(m.t){
  case 'plan':if(!(m.plan in rank))break;if(process.env.STRIPE_KEY&&m.plan!=='free')return err('Paiement requis (Stripe non branché)');u.plan=m.plan;push(u);break;
  case 'join':{const code=m.code?String(m.code):'',rm=code?(Object.values(db.rooms).find(r=>r.priv&&r.code===code)||{}).id:m.room;
   if(!rm||!rooms[rm])return err('Fréquence introuvable');
   if(db.rooms[rm]&&db.rooms[rm].priv&&db.rooms[rm].code!==code)return err('Code invalide');
   if(rooms[rm].size>=MAXP&&!rooms[rm].has(u.id))return err('Salon plein ('+MAXP+' max)');
   leave(u.id);const list=[...rooms[rm]].map(i=>({id:i,name:db.users[i].name,frame:db.users[i].frame}));
   rooms[rm].add(u.id);where.set(u.id,rm);
   send(ws,{t:'peers',room:rm,name:db.rooms[rm]?db.rooms[rm].name:'Fréquence '+rm.slice(1),list});
   rooms[rm].forEach(p=>p!==u.id&&to(p,{t:'joined',id:u.id,name:u.name,frame:u.frame}));bcast();pushFriends(u);break}
  case 'leave':leave(u.id);pushFriends(u);break;
  case 'sig':if(where.get(u.id)&&where.get(u.id)===where.get(m.to))to(m.to,{t:'sig',from:u.id,data:m.data});break;
  case 'talking':{u.lastTalk=Date.now();const r=where.get(u.id);r&&rooms[r].forEach(p=>p!==u.id&&to(p,{t:'talk',id:u.id,on:!!m.on}));break}
  case 'mkroom':{const name=String(m.name||'').trim().slice(0,24);if(!name)return err('Nom requis');
   if(Object.values(db.rooms).filter(r=>r.owner===u.id).length>=10)return err('Maximum 10 fréquences');
   const id='c'+rid();db.rooms[id]={id,name,priv:!!m.priv,code:m.priv?String(Math.floor(1e5+Math.random()*9e5)):null,owner:u.id};rooms[id]=new Set();push(u);bcast();break}
  case 'friend':{const t=all().find(x=>x.name.toLowerCase()===String(m.name||'').trim().toLowerCase());
   if(!t||t===u)return err('Utilisateur introuvable');if(t.set.noFriends)return err("Cet utilisateur n'accepte pas les demandes d'amis");
   if(!u.friends.includes(t.id)){u.friends.push(t.id);t.friends.push(u.id)}push(u);push(t);break}
  case 'set':{if(['blue','violet','emerald'].includes(m.theme)){if(!R&&m.theme!=='blue')return err('Thèmes réservés à Freqo Plus');u.theme=m.theme}
   if(['none','pulse','gold'].includes(m.frame)){if(!R&&m.frame!=='none')return err('Cadres réservés à Freqo Plus');u.frame=m.frame}
   if(m.notif!==undefined)u.set.notif=!!m.notif;if(m.noFriends!==undefined)u.set.noFriends=!!m.noFriends;push(u);break}
  case 'flist':send(ws,{t:'flist',list:Object.values(db.factions).filter(f=>f.recruiting).map(f=>({id:f.id,name:f.name,emblem:f.emblem,n:f.members.length}))});break;
  case 'fcreate':case 'fjoin':{if(u.faction)return err('Tu es déjà dans une faction');
   if(u.voice<REQ)return err('Il faut 10 h de participation vocale active (vérifié par le serveur)');
   if(m.t==='fcreate'){const name=String(m.name||'').trim().slice(0,24);if(name.length<3)return err('Nom trop court');const id=rid();db.factions[id]={id,name,owner:u.id,members:[u.id],color:'#8b5cf6',emblem:'⚡',desc:'',recruiting:true,events:[]};u.faction=id}
   else{const f=db.factions[m.id];if(!f||!f.recruiting)return err('Recrutement fermé');f.members.push(u.id);u.faction=f.id}
   push(u);break}
  case 'fleave':{const f=db.factions[u.faction];if(!f)break;f.members=f.members.filter(i=>i!==u.id);u.faction=null;
   if(!f.members.length)delete db.factions[f.id];else if(f.owner===u.id)f.owner=f.members[0];
   push(u);f.members.forEach(i=>push(db.users[i]));break}
  case 'fedit':case 'fevent':{const f=db.factions[u.faction];if(!f||f.owner!==u.id)return err('Réservé au chef de faction');
   if(u.plan!=='clan')return err('Réservé à Freqo Clan');
   if(m.t==='fedit'){if(/^#[0-9a-f]{6}$/i.test(m.color))f.color=m.color;f.emblem=String(m.emblem||f.emblem).slice(0,2);f.desc=String(m.desc||'').slice(0,300);f.recruiting=!!m.recruiting}
   else{const title=String(m.title||'').slice(0,40);if(!title)return err('Titre requis');f.events=[...f.events,{title,date:String(m.date||'').slice(0,16)}].slice(-20)}
   f.members.forEach(i=>push(db.users[i]));break}
  case 'sfx':{if(!R)return err('Soundboard réservé à Freqo Plus');const r=where.get(u.id);r&&rooms[r].forEach(p=>p!==u.id&&to(p,{t:'sfx',n:(+m.n||0)%6}));break}
  }});
 ws.on('close',()=>{if(u&&conns.get(u.id)===ws){leave(u.id);conns.delete(u.id);pushFriends(u)}});
});
setInterval(()=>wss.clients.forEach(w=>w.readyState===1&&w.ping()),25000); // garde les WebSockets ouverts derrière un proxy
// Temps vocal "actif" : salon à 2+ personnes ET prise de parole détectée dans les 5 dernières minutes
let tick=0;setInterval(()=>{const now=Date.now();tick++;
 Object.values(rooms).forEach(s=>{if(s.size>1)s.forEach(i=>{const x=db.users[i];if(x&&now-(x.lastTalk||0)<3e5)x.voice+=5})});
 if(tick%6===0)conns.forEach((w,i)=>push(db.users[i]))},5000);
server.listen(PORT,()=>console.log('Freqo : http://localhost:'+PORT));
